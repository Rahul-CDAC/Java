package com.example.first;

public class A {
	private int num1 = 10;
	int num2 = 20;
	protected int num3 = 30;
	public int num4 = 40;

	public void print( ) {
		//System.out.println("Num1	:	"+num1);	//OK
		//System.out.println("Num2	:	"+num2);	//OK
		//System.out.println("Num3	:	"+num3);	//OK
		System.out.println("Num4	:	"+num4);	//OK
	}
}
